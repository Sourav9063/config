# Security Policy

## Reporting a Vulnerability

Please _do not_ open an issue for a security vulnerability.

Instead, please send an email to jasonfields4@gmail.com with "SECURITY" in the subject. I should get back to you within 48 hours; please follow up with another email if I do not.
