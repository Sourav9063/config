export enum SpecialKeys {
  ExtensionEnable = '<ExtensionEnable>',
  ExtensionDisable = '<ExtensionDisable>',
  TimeoutFinished = '<TimeoutFinished>',
}
