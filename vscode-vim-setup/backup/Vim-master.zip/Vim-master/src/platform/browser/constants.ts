export const SUPPORT_VIMRC = false;
export const SUPPORT_NVIM = false;
export const SUPPORT_IME_SWITCHER = false;
export const SUPPORT_READ_COMMAND = false;
