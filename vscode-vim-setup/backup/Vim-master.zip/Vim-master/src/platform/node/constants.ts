export const SUPPORT_VIMRC = true;
export const SUPPORT_NVIM = true;
export const SUPPORT_IME_SWITCHER = true;
export const SUPPORT_READ_COMMAND = true;
